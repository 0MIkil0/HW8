<template>
  <div>
    <NavPage></NavPage>
  </div>
  <div v-if="username">
    <div class="chat">
      <h2>чат</h2>
      <div class="text" v-for="message in messages" :key="message.id">
        {{ message.user }}: {{ message.text }}
        <button @click="deleteMsg(message.id)">Удалить</button>
      </div>
      <div v-show="emptyMsg" class="empty">Текущих сообщений нет</div>
    </div>
    <input v-model="newMessage" placeholder="введите сообщение" @keydown.enter="sendMsg">
    <button @click="sendMsg">Отправить</button>
    <button v-show="deleteBtn" @click="delMsg">Удалить всё</button>
  </div>
  <div v-else class="alert">
    Для авторизации перейдите по <router-link :to="{ name: 'Home' }">ссылке</router-link>
  </div>
</template>

<script>
import NavPage from './NavPage.vue'
export default {
  components: {
    NavPage
  },
  data() {
    return {
      messages: [],
      newMessage: '',
      deleteBtn: false,
      emptyMsg: true,
      username: ''
    }
  },

  mounted() {
    this.username = localStorage.getItem("username");
    this.messages = JSON.parse(localStorage.getItem("messages")) || [];
    this.saveMessages();
  },

  methods: {
    delMsg() {
      this.messages = [];
      this.deleteBtn = false;
      this.saveMessages();
    },
    deleteMsg(id) {
      this.messages = this.messages.filter(message => message.id !== id);
      this.saveMessages();
    },
    sendMsg() {
      if (this.username === '') {
        this.username = 'Аноним';
      }
      if (this.newMessage !== '') {
        this.emptyMsg = false;
        this.messages.push({ id: new Date().getTime(), text: this.newMessage, user: this.username });
        this.newMessage = '';
        this.deleteBtn = true;
        this.saveMessages();
      }
    },
    saveMessages() {
      this.emptyMsg = this.messages.length === 0;
      localStorage.setItem("messages", JSON.stringify(this.messages));
    }
  }
}
</script>

<style scoped>
/* Ваш стиль */
</style>
