<template>
  <div>
    <NavPage></NavPage>

    <div v-if="isAuth">
      <div>привествую, пользователь <b>{{ username }}</b></div>
      <button @click="logout">Выйти</button>
    </div>

    <div v-else>
      <label>Ввести ваше имя:</label>
      <v-input v-model="username" @keyup.enter="login"></v-input>
      <v-btn @click="login">Войти</v-btn>
    </div>
  </div>
</template>
 
<script>

import NavPage from './NavPage.vue'
export default {
  components: {
    NavPage,

  },
  data() {
    return {
      isAuth: false,
      username: ""
    }
  },
  mounted() {
    const localStorageAuth = localStorage.getItem('isAuth');
    const localStorageUsername = localStorage.getItem('username');
    if (localStorageAuth && localStorageUsername) {
      this.isAuth = true;
      this.username = localStorageUsername;
    }
  },
  methods: {
    login() {
      if (this.username.trim() !== "") {
        this.isAuth = true;

        localStorage.setItem('isAuth', true);
        localStorage.setItem('username', this.username);

        this.$router.push({
          name: 'Chat',
          query: { username: this.username }
        })
      }
      else {
        alert('Введите имя');
      }
    },
    logout() {
      this.isAuth = false;
      this.username = "";

      localStorage.removeItem('isAuth');
      localStorage.removeItem('username');
    }
  }
} 
</script>

<style >
@import 'vuetify/dist/vuetify.min.css';
</style>


