<template>
  <div class="NavBar">
    <router-link class='router' to="/">Домашняя страница &nbsp</router-link>
    <router-link class='router' to="chat">чат &nbsp</router-link>
    <router-link class='router' to="test">API данные</router-link>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.NavBar {
  display: flex;
  align-items: center;
  justify-content: center;
 
}
.router{
  text-decoration: none;
}
</style>
