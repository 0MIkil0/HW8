<template>

  <router-view></router-view>
  
</template>

<script>
import NavPage from "./components/NavPage.vue"

export default {
  components: {
    NavPage
  }
}
</script>

<style >

@import 'vuetify/dist/vuetify.min.css';


</style>
